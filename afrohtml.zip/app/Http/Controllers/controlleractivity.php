<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class controlleractivity extends Controller
{
    //
}
