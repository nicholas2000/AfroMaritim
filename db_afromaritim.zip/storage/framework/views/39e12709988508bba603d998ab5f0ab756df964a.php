<body>
    <section class="order-form m-4">
        <div class="container pt-4">
            <div class="container">
                <div class="col-12 ">
                    <h1> Rekap Kontainer</h1>
                    <hr class="mt" />
                </div>
                <br>
                <div class="col-12">
                    <a href="<?php echo e(url('/addContainer')); ?>"> <button style="float: right;" type="button"
                            class="btn btn-primary">Tambah</button></a>
                </div>
                <br><br>
                <div class="col-12">
                    <table class="table table-bordered" id="myTable">
                        <tr style="background-color:  #023e94;color: white;">
                            <th scope="col"class="col-1">No</th>
                            <th scope="col"class="col-2">
                                <center>No Container</center>
                            </th>
                            <th scope="col" class="col-2">
                                <center>Tgl Closing</center>
                            </th>
                            <th scope="col"class="col-2">
                                <center>Status</center>
                            </th>
                            <th scope="col" class="col-1">
                                <center>Action</center>
                            </th>
                            <th scope="col" class="col-1">
                                <center>Lihat Isi</center>
                            </th>
                        </tr>
                        <?php $ctr = 1; ?>
                        <?php $__currentLoopData = $arrCon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ctr); ?></td>
                                <td name="nomor_container"><?php echo e($prm->nomor_container); ?></td>
                                <td><?php echo e($prm->tanggal); ?></td>
                                <?php if($prm->status == '1'): ?>
                                    <td>Buka</td>
                                    <td style="text-align: center;">
                                        <form method="post"
                                            action="<?php echo e(url('masterContainer/lock/' . $prm->nomor_container)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button style="height: 29px;background-color: green;color:white"
                                                class="btn" id="btnopen<?php echo e($prm->nomor_container); ?>"
                                                onclick="clickClose('<?php echo e($prm->nomor_container); ?>')"><i
                                                    class="fa fa-unlock"></i></button>
                                        </form>
                                    </td>
                                <?php else: ?>
                                    <td>Tutup</td>
                                    <td style="text-align: center;">
                                        <form method="post"
                                            action="<?php echo e(url('masterContainer/unlock/' . $prm->nomor_container)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button style="height: 29px;background-color: red;color:white;"
                                                class="btn " id="btnclose<?php echo e($prm->nomor_container); ?>"
                                                onclick="clickOpen('<?php echo e($prm->nomor_container); ?>')">
                                                <i class="fa fa-lock"></i>
                                            </button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                                <td>
                                    <center style="text-align:center">
                                        <button style="height: 29px;" class="btn" id="btnedit"
                                            data-toggle="modal"name="edit" data-target="#myModal"
                                            onclick="btnedit('<?php echo e($prm->nomor_container); ?>')"><i class="fa fa-eye"></i></button>
                                    </center>
                                </td>
                            </tr>

                            <?php $ctr++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>

                </div>
                <div id="myModal" class="modal fade">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4>Isi Cabang</h4>
                                <button class="close" type="button" data-dismiss="modal">×</button>
                            </div>
                            <input type="hidden" id="data1" value="<?php echo e($arrTransaksi); ?>">
                            <div class="modal-body">
                                <div class="popup table table-striped">
                                    <form action="<?php echo e(url('masterCustomer/edit/')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th scope="col">#</th>
                                                    <th scope="col">Container</th>
                                                    <th scope="col">No STT</th>
                                                    <th scope="col">Nama Barang</th>
                                                    <th scope="col">Tanggal Pengiriman</th>
                                                    <th scope="col">Colly</th>
                                                </tr>
                                            </thead>
                                            <tbody id="list_container">

                                            </tbody>
                                        </table>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
    </section>
    <script>
        function clickOpen($id) {
            document.getElementById("btnopen" + $id).style.display = "block";
            document.getElementById("btnclose" + $id).style.display = "none";
        }

        function clickClose($id) {
            document.getElementById("btnclose" + $id).style.display = "block";
            document.getElementById("btnopen" + $id).style.display = "none";
        }

        function btnedit($id) {
            $.ajax({
                url: "autocomplete.php",
                method: "POST",
                data: {
                    query: $id,
                    ctr: "LihatContainer"
                },
                success: function(data) {
                    $('#list_container').html("");
                    $('#list_container').append(data);
                }
            });
        }
    </script>




</body>

</html>
<?php /**PATH C:\Afro\AfroMaritim\resources\views/form/formContainer.blade.php ENDPATH**/ ?>