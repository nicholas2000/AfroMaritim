<body>
    <section class="order-form m-4">
        <div class="container pt-4">
            <div class="container">
                <div class="col-12 ">
                    <h1> Form Master Kompetitor</h1>
                    <hr class="mt" />
                </div>
                <br>

                <div class="col-12">
                    <a href="<?php echo e(url('/addKompetitor')); ?>"> <button style="float: right;" type="button"
                            class="btn btn-primary">Tambah</button></a>
                </div>
                <br><br>
                <div class="col-12">
                    <table class="table table-bordered">
                        <tr style="background-color:  #023e94;color: white;">
                            <th scope="col">No</th>
                            <th scope="col">
                                <center>ID Kompetitor</center>
                            </th>
                            <th scope="col">
                                <center>Nama Kompetitor</center>
                            </th>
                            <th scope="col">
                                <center>Alamat Kompetitor</center>
                            </th>
                            <th scope="col">
                                <center>Email </center>
                            </th>
                            <th scope="col">
                                <center>Action</center>
                            </th>
                        </tr>
                        <?php $ctr = 1; ?>
                        <?php $__currentLoopData = $arrKompetitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($ctr); ?></th>
                                <th scope="col">
                                    <center><?php echo e($prm->id_kompetitor); ?></center>
                                </th>
                                <th scope="col">
                                    <center><?php echo e($prm->nama_kompetitor); ?></center>
                                </th>
                                <th scope="col">
                                    <center><?php echo e($prm->alamat_kompetitor); ?></center>
                                </th>
                                <th scope="col">
                                    <center><?php echo e($prm->email_kompetitor); ?></center>
                                </th>
                                <th scope="col">
                                    <center style="display: flex;">
                                        <button style="height: 29px;" class="btn" id="btnedit" data-toggle="modal"
                                            data-target="#myModal" onclick="btnedit(<?php echo e($ctr - 1); ?>)"><i
                                                class="fa fa-pencil"></i></button>

                                        <form method="post"
                                            action="<?php echo e(url('masterKompetitor/delete/' . $prm->id_kompetitor)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger"><i
                                                    class="fa fa-trash"></i></button>
                                        </form>
                                    </center>
                                </th>
                            </tr>
                            <?php $ctr++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </table>
                </div>
            </div>
    </section>
</body>

</html>
<?php /**PATH C:\Afro\AfroMaritim\resources\views/form/formMasterkompetitor.blade.php ENDPATH**/ ?>