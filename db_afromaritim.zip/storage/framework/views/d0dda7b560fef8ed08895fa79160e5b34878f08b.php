<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <section class="order-form m-4">
        <div class="container pt-4">
            <div class="container">
                <div class="col-12 ">
                    <h1> Form Master Kompetitor</h1>
                    <hr class="mt" />
                </div>
                <br>

                <div class="col-12">
                 <a href="<?php echo e(url('/tkompetitor')); ?>">  <button style="float: right;" type="button" class="btn btn-primary">Tambah</button></a>
                </div>
                <br><br>
                <div class="col-12">
                    <table class="table table-bordered">
                        <tr style="background-color:  #023e94;color: white;">
                                <th scope="col">No</th>
                                <th scope="col"> <center>ID Kompetitor</center> </th>
                                <th scope="col"> <center>Nama Kompetitor</center> </th>
                                <th scope="col"> <center>Alamat Kompetitor</center> </th>
                                <th scope="col"> <center>Email </center> </th>
                                <th scope="col"> <center>No HP</center> </th>
                                <th scope="col"> <center>Action</center> </th>
                            </tr>
                            <?php $ctr = 1;?>
                            <?php $__currentLoopData = $arrKompetitor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <th scope="row"><?php echo e($ctr); ?></th>
                                <th scope="col"> <center><?php echo e($prm->id_kompetitor); ?></center> </th>
                                <th scope="col"> <center><?php echo e($prm->nama_kompetitor); ?></center> </th>
                                <th scope="col"> <center><?php echo e($prm->alamat_kompetitor); ?></center> </th>
                                <th scope="col"> <center><?php echo e($prm->email_kompetitor); ?></center> </th>
                                <th scope="col"> <center><?php echo e($prm->nohp_kompetitor); ?></center> </th>
                                <th scope="col">
                                    <center>
                                        <button type="button" name=""  class="btn btn"><i class="fa fa-pencil-alt"></i></button>
                                        <button style="margin-left: 2%" name="" type="button" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                    </center>
                                </th>
                            </tr>
                            <?php $ctr++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </table>
                </div>

            </div>
    </section>




</body>

</html>
<?php /**PATH D:\Albert\Semester8\GITHUBDesktoppaperus\GitDeusAfroMaritim\AfroMaritim\resources\views/form/formMasterkompetitor.blade.php ENDPATH**/ ?>