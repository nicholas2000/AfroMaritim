<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->


<!DOCTYPE html>
<html class=''>

<head>
    <script
        src='//production-assets.codepen.io/assets/editor/live/console_runner-079c09a0e3b9ff743e39ee2d5637b9216b3545af0de366d4b9aad9dc87e26bfd.js'>
    </script>
    <script
        src='//production-assets.codepen.io/assets/editor/live/events_runner-73716630c22bbc8cff4bd0f07b135f00a0bdc5d14629260c3ec49e5606f98fdd.js'>
    </script>
    <script
        src='//production-assets.codepen.io/assets/editor/live/css_live_reload_init-2c0dc5167d60a5af3ee189d570b1835129687ea2a61bee3513dee3a50c115a77.js'>
    </script>
    <meta charset='UTF-8'>
    <meta name="robots" content="noindex">
    <link rel="shortcut icon" type="image/x-icon"
        href="//production-assets.codepen.io/assets/favicon/favicon-8ea04875e70c4b0bb41da869e81236e54394d63638a1ef12fa558a4a835f1164.ico" />
    <link rel="mask-icon" type=""
        href="//production-assets.codepen.io/assets/favicon/logo-pin-f2d2b6d2c61838f7e76325261b7195c27224080bc099486ddd6dccb469b8e8e6.svg"
        color="#111" />
    <link rel="canonical" href="https://codepen.io/andytran/pen/GJOBZj?limit=all&page=8&q=login" />

    <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css'>
    <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
    <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
    <style class="cp-pen-styles">
        /* Form */
    </style>
</head>

<body>

    <link rel="stylesheet" href="style.css">
    <div class="container">
        <div class="info">
            <h1>PT. AFRO TRANS MARITIM</h1>
        </div>
        @if (Session::has('error'))
            <div class="alert alert-danger alert-dismissible" id="box" role="alert">
                {{ Session::get('error') }}
                <button type="button" class="fa fa-times" data-bs-dismiss="alert" aria-label="Close" onclick="myFunction()" style="float: right;border: none;background: none;"></button>
            </div>
        @endif
    </div>
    <div class="form">
        <div class=><img style="margin-top: -15px" src="logo.png" /></div>
        <form class="login-form" action="{{ url('/login') }}">
            <input name="user" type="text" placeholder="Username" />
            <input name="password" type="TEXT" placeholder="Password" />
            <input type="submit" style="color:white;background-color:#023e94" value="Login">
            {{-- @if (Session::has('error'))
        <p class="alert "> {{ Session::get('error') }}</p>
    @endif --}}
            <p class="message"> <a href="">Forgot Password</a></p>
        </form>
    </div>


    <script
        src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'>
    </script>
    <script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script>
        function myFunction() {
            document.getElementById("box").style.display="none";
        }
    </script>
</body>

</html>
